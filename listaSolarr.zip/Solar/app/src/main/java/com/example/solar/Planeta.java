package com.example.solar;

public class Planeta {
    String nome;
    int image;

    public Planeta(Object nome, int image) {
        this.nome = (String) nome;
        this.image = image;
    }
}
